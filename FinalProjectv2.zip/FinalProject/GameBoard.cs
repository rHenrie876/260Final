﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    internal class GameBoard : Array
    {
        public static void Board()
        {
            Console.WriteLine("");
            Console.WriteLine("   |   |   ");
            Console.WriteLine(" {0} | {1} | {2}", Array.arr[1], Array.arr[2], Array.arr[3]);
            Console.WriteLine("___|___|___");
            Console.WriteLine("   |   |  ");
            Console.WriteLine(" {0} | {1} | {2}", Array.arr[4], Array.arr[5], Array.arr[6]);
            Console.WriteLine("___|___|___");
            Console.WriteLine("   |   |   ");
            Console.WriteLine(" {0} | {1} | {2}", Array.arr[7], Array.arr[8], Array.arr[9]);
            Console.WriteLine("   |   |   ");
            Console.WriteLine("");
        }
    }
}
