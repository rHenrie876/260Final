﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    internal class Program : Array
    {
        static int player = 1;
        static int move;

        static void Main(string[] args)
        {
            for (int i = 0; i <= 9; i++)
            {
                if (i == 9)
                {
                    Console.WriteLine("\nTied game! Better luck next time!\n");
                    break;
                }

                Console.Clear();
                GameBoard.Board();
                Console.WriteLine("Begin game! Player 1 is X and Player 2 is O!\n\n");
                Console.WriteLine("Turn {0}", player);
                if (player % 2 == 1)
                {
                    Console.WriteLine("Player 1's turn!\n");
                }
                else if (player % 2 == 0)
                {
                    Console.WriteLine("Player 2's turn!\n");
                }

                move = Convert.ToInt32(Console.ReadLine());

                if (move <= 9 && move >= 1)
                {
                    if (Array.arr[move] != 'X' && Array.arr[move] != 'O')
                    {
                        if (player % 2 == 1)
                        {
                            Array.arr[move] = 'X';
                            player++;
                        }

                        else
                        {
                            Array.arr[move] = 'O';
                            player++;
                        }
                    }

                    else if (move > 9 || move < 1 || Array.arr[move] == 'X' || Array.arr[move] == 'O')
                    {
                        Check(move);
                    }

                }

                Console.Clear();
                GameBoard.Board();

                if(Win.WinCon1(Array.arr) == 1)
                {
                    Console.WriteLine("\nPlayer 1 wins! Good game!\n");
                    break;
                }

                if(Win.WinCon2(Array.arr) == 2)
                {
                    Console.WriteLine("\nPlayer 2 wins! good game!\n");
                    break;
                }
            }
        }


        public static void Check(int x)
        {
            if (x < 0 || x > 9 || Array.arr[x] == 'X' || Array.arr[x] == 'O')
            {
                Console.WriteLine("Invalid input. Please try again!\n");
                x = Convert.ToInt32(Console.ReadLine());
                Check(x);
            }
        }
    }
}
