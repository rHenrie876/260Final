﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    public class Win : Array
    {
        public static int WinCon1(char[] argc)
        {
            if (Array.arr[1] == 'X' && Array.arr[2] == 'X' && Array.arr[3] == 'X')
            {
                return (1);
            }

            else if (Array.arr[4] == 'X' && Array.arr[5] == 'X' && Array.arr[6] == 'X')
            {
                return (1);
            }

            else if (Array.arr[7] == 'X' && Array.arr[8] == 'X' && Array.arr[9] == 'X')
            {
                return (1);
            }

            else if (Array.arr[1] == 'X' && Array.arr[4] == 'X' && Array.arr[7] == 'X')
            {
                return (1);
            }

            else if (Array.arr[2] == 'X' && Array.arr[5] == 'X' && Array.arr[8] == 'X')
            {
                return (1);
            }
            
            else if (Array.arr[3] == 'X' && Array.arr[5] == 'X' && Array.arr[9] == 'X')
            {
                return (1);
            }
            
            else if (Array.arr[1] == 'X' && Array.arr[5] == 'X' && Array.arr[9] == 'X')
            {
                return (1);
            }

            else if (Array.arr[3] == 'X' && Array.arr[5] == 'X' && Array.arr[7] == 'X')
            {
                return (1);
            }

            else
                return (0);
        }

        public static int WinCon2(char[] argc)
        {
            if (Array.arr[1] == 'O' && Array.arr[2] == 'O' && Array.arr[3] == 'O')
            {
                return (2);
            }

            else if (Array.arr[4] == 'O' && Array.arr[5] == 'O' && Array.arr[6] == 'O')
            {
                return (2);
            }

            else if (Array.arr[7] == 'O' && Array.arr[8] == 'O' && Array.arr[9] == 'O')
            {
                return (2);
            }

            else if (Array.arr[1] == 'O' && Array.arr[4] == 'O' && Array.arr[7] == 'O')
            {
                return (2);
            }

            else if (Array.arr[2] == 'O' && Array.arr[5] == 'O' && Array.arr[8] == 'O')
            {
                return (2);
            }

            else if (Array.arr[3] == 'O' && Array.arr[5] == 'O' && Array.arr[9] == 'O')
            {
                return (2);
            }

            else if (Array.arr[1] == 'O' && Array.arr[5] == 'O' && Array.arr[9] == 'O')
            {
                return (2);
            }

            else if (Array.arr[3] == 'O' && Array.arr[5] == 'O' && Array.arr[7] == 'O')
            {
                return (2);
            }

            else
                return (0);
        }

    }
}
